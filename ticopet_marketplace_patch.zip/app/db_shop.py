import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[1] / "ticopet.db"

def conn():
    return sqlite3.connect(DB_PATH)

def ensure_shop_tables():
    c = conn()
    cur = c.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS shop_products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT,
            price REAL NOT NULL,
            stock INTEGER NOT NULL DEFAULT 0,
            description TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS shop_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            total REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS shop_order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            qty INTEGER NOT NULL,
            price REAL NOT NULL
        )
    """)
    c.commit()
    c.close()

def seed_products_if_empty():
    ensure_shop_tables()
    c = conn()
    cur = c.cursor()
    cur.execute("SELECT COUNT(*) FROM shop_products")
    n = cur.fetchone()[0]
    if n == 0:
        items = [
            ("Concentrado Premium 10kg", "Alimento", 38500, 20, "Alimento balanceado para perros adultos."),
            ("Arena sanitaria 5kg", "Higiene", 9900, 35, "Aglomerante, control de olores."),
            ("Collar ajustable M", "Accesorios", 5500, 50, "Nylon, color azul."),
            ("Juguete mordedero", "Accesorios", 3200, 60, "Goma resistente."),
            ("Antipulgas spot-on", "Medicamentos", 12900, 25, "Para perros 10-20kg."),
            ("Pecera 20L", "Acuáticos", 29900, 10, "Vidrio con tapa."),
            ("Heno Timothy 1kg", "Alimento", 7800, 40, "Para conejos y roedores."),
            ("Vitaminas multiespecie", "Medicamentos", 8500, 30, "Suplemento general."),
        ]
        cur.executemany("""
            INSERT INTO shop_products (name, category, price, stock, description)
            VALUES (?, ?, ?, ?, ?)
        """, items)
        c.commit()
    c.close()

def list_categories():
    ensure_shop_tables()
    c = conn()
    cur = c.cursor()
    cur.execute("SELECT DISTINCT COALESCE(category,'') FROM shop_products ORDER BY 1")
    cats = [r[0] for r in cur.fetchall() if r[0] is not None]
    c.close()
    return cats

def list_products(name_filter: str = "", category: str = ""):
    ensure_shop_tables()
    c = conn()
    cur = c.cursor()
    q = "SELECT id, name, category, price, stock, description FROM shop_products WHERE 1=1"
    params = []
    if name_filter:
        q += " AND LOWER(name) LIKE ?"
        params.append(f"%{name_filter.lower()}%")
    if category:
        q += " AND category = ?"
        params.append(category)
    q += " ORDER BY name COLLATE NOCASE"
    cur.execute(q, params)
    rows = cur.fetchall()
    c.close()
    return rows

def get_product(prod_id: int):
    ensure_shop_tables()
    c = conn()
    cur = c.cursor()
    cur.execute("SELECT id, name, category, price, stock, description FROM shop_products WHERE id = ?", (prod_id,))
    row = cur.fetchone()
    c.close()
    return row

def create_order(user_id: int, items: list[tuple[int, int]]):
    ensure_shop_tables()
    if not items:
        return None
    c = conn()
    try:
        cur = c.cursor()
        total = 0.0
        for pid, qty in items:
            cur.execute("SELECT price, stock FROM shop_products WHERE id = ?", (pid,))
            row = cur.fetchone()
            if not row:
                raise ValueError("Producto no existe")
            price, stock = row
            if qty <= 0 or stock < qty:
                raise ValueError("Stock insuficiente o cantidad inválida")
            total += price * qty

        cur.execute("INSERT INTO shop_orders (user_id, total) VALUES (?, ?)", (user_id, total))
        order_id = cur.lastrowid

        for pid, qty in items:
            cur.execute("SELECT price FROM shop_products WHERE id = ?", (pid,))
            price = cur.fetchone()[0]
            cur.execute("""
                INSERT INTO shop_order_items (order_id, product_id, qty, price)
                VALUES (?, ?, ?, ?)
            """, (order_id, pid, qty, price))
            cur.execute("UPDATE shop_products SET stock = stock - ? WHERE id = ?", (qty, pid))

        c.commit()
        return order_id
    except Exception:
        c.rollback()
        return None
    finally:
        c.close()
