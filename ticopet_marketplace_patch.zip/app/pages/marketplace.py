import tkinter as tk
from tkinter import ttk, messagebox
from app.db_shop import ensure_shop_tables, seed_products_if_empty, list_categories, list_products, create_order

class MarketplacePage(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding=16)
        ttk.Label(self, text="Marketplace (tienda)", style="H2.TLabel").grid(row=0, column=0, sticky="w", pady=(0,8))

        self.blocked = ttk.Frame(self)
        msg = ("Solo los clientes pueden comprar en la tienda.\n"
               "Los veterinarios pueden gestionar inventario en otra sección (futuro).")
        ttk.Label(self.blocked, text=msg, justify="left").grid(row=0, column=0, sticky="w", pady=(6,0))

        self.client = ttk.Frame(self)
        row = 0
        ttk.Label(self.client, text="Buscar").grid(row=row, column=0, sticky="w")
        self.search_var = tk.StringVar()
        ttk.Entry(self.client, textvariable=self.search_var, width=28).grid(row=row, column=1, sticky="w")
        ttk.Label(self.client, text="Categoría").grid(row=row, column=2, sticky="w")
        self.cat_var = tk.StringVar()
        self.cb_cat = ttk.Combobox(self.client, textvariable=self.cat_var, width=20, state="readonly")
        self.cb_cat.grid(row=row, column=3, sticky="w")
        ttk.Button(self.client, text="Filtrar", command=self._load_products).grid(row=row, column=4, sticky="w", padx=6)
        ttk.Button(self.client, text="Limpiar", command=self._clear_filters).grid(row=row, column=5, sticky="w")

        row += 1
        cols = ("id","name","category","price","stock")
        self.tree = ttk.Treeview(self.client, columns=cols, show="headings", height=12)
        self.tree.grid(row=row, column=0, columnspan=6, sticky="nsew", pady=(8,4))
        self.client.rowconfigure(row, weight=1)
        for c, t, w in [("id","ID",50),("name","Producto",240),("category","Categoría",120),("price","Precio",90),("stock","Stock",70)]:
            self.tree.heading(c, text=t)
            self.tree.column(c, width=w, anchor="w")
        row += 1
        ttk.Label(self.client, text="Cantidad").grid(row=row, column=0, sticky="w")
        self.qty_var = tk.StringVar(value="1")
        ttk.Entry(self.client, textvariable=self.qty_var, width=6).grid(row=row, column=1, sticky="w")
        ttk.Button(self.client, text="Añadir al carrito", command=self._add_to_cart).grid(row=row, column=2, sticky="w")

        cart_frame = ttk.Frame(self.client)
        cart_frame.grid(row=1, column=6, rowspan=3, sticky="nsw", padx=(12,0))
        ttk.Label(cart_frame, text="Carrito", style="H3.TLabel").pack(anchor="w")
        self.cart_tree = ttk.Treeview(cart_frame, columns=("name","qty","subtotal"), show="headings", height=10)
        self.cart_tree.heading("name", text="Producto")
        self.cart_tree.heading("qty", text="Cant.")
        self.cart_tree.heading("subtotal", text="Subtotal")
        self.cart_tree.column("name", width=220, anchor="w")
        self.cart_tree.column("qty", width=60, anchor="center")
        self.cart_tree.column("subtotal", width=100, anchor="e")
        self.cart_tree.pack(fill="both", expand=True, pady=(4,4))
        self.total_var = tk.StringVar(value="Total: ₡0.00")
        ttk.Label(cart_frame, textvariable=self.total_var).pack(anchor="e", pady=(0,6))
        btns = ttk.Frame(cart_frame)
        btns.pack(anchor="e")
        ttk.Button(btns, text="Vaciar", command=self._clear_cart).pack(side="left")
        ttk.Button(btns, text="Pagar", command=self._checkout).pack(side="left", padx=6)

        self.client.columnconfigure(0, weight=1)
        self.client.columnconfigure(1, weight=0)
        self.client.columnconfigure(2, weight=0)
        self.client.columnconfigure(3, weight=0)
        self.client.columnconfigure(4, weight=0)
        self.client.columnconfigure(5, weight=0)

        self.cart = {}

        self.bind("<Visibility>", lambda e: self.refresh())

    def _is_client(self):
        root = self.winfo_toplevel()
        role = (getattr(root, "current_user_role", "") or "").strip().lower()
        return role == "cliente" and getattr(root, "current_user_id", None) is not None

    def refresh(self):
        ensure_shop_tables()
        seed_products_if_empty()

        if self._is_client():
            self.blocked.grid_forget()
            self.client.grid(row=1, column=0, sticky="nsew")
            self._load_filters()
            self._load_products()
        else:
            self.client.grid_forget()
            self.blocked.grid(row=1, column=0, sticky="nw")

    def _load_filters(self):
        cats = [""] + list_categories()
        self.cb_cat["values"] = cats
        if not self.cat_var.get() in cats:
            self.cat_var.set("")

    def _clear_filters(self):
        self.search_var.set("")
        self.cat_var.set("")
        self._load_products()

    def _load_products(self):
        name = (self.search_var.get() or "").strip()
        cat = (self.cat_var.get() or "").strip()
        rows = list_products(name_filter=name, category=cat)
        self.tree.delete(*self.tree.get_children())
        for pid, name, category, price, stock, desc in rows:
            self.tree.insert("", "end", values=(pid, name, category or "", f"₡{price:,.2f}", stock))

    def _add_to_cart(self):
        sel = self.tree.focus()
        if not sel:
            messagebox.showwarning("Marketplace", "Seleccione un producto.")
            return
        values = self.tree.item(sel, "values")
        pid = int(values[0])
        name = str(values[1])
        price_text = values[3].replace("₡","").replace(",","")
        try:
            price = float(price_text)
        except:
            messagebox.showerror("Marketplace", "Precio inválido.")
            return
        try:
            qty = int(self.qty_var.get())
        except:
            messagebox.showwarning("Marketplace", "Cantidad inválida.")
            return
        if qty <= 0:
            messagebox.showwarning("Marketplace", "La cantidad debe ser positiva.")
            return

        cur = self.cart.get(pid, (name, price, 0))
        new_qty = cur[2] + qty
        self.cart[pid] = (name, price, new_qty)
        self._refresh_cart()

    def _refresh_cart(self):
        self.cart_tree.delete(*self.cart_tree.get_children())
        total = 0.0
        for pid, (name, price, qty) in self.cart.items():
            subtotal = price * qty
            total += subtotal
            self.cart_tree.insert("", "end", values=(name, qty, f"₡{subtotal:,.2f}"))
        self.total_var.set(f"Total: ₡{total:,.2f}")

    def _clear_cart(self):
        self.cart.clear()
        self._refresh_cart()

    def _checkout(self):
        if not self._is_client():
            messagebox.showwarning("Marketplace", "Solo clientes pueden pagar.")
            return
        if not self.cart:
            messagebox.showwarning("Marketplace", "El carrito está vacío.")
            return
        items = [(pid, qty) for pid, (_, _, qty) in self.cart.items()]
        user_id = self.winfo_toplevel().current_user_id
        order_id = create_order(user_id, items)
        if order_id:
            messagebox.showinfo("Marketplace", f"Compra realizada. Número de orden #{order_id}. ¡Gracias!")
            self._clear_cart()
            self._load_products()
        else:
            messagebox.showerror("Marketplace", "No se pudo completar la compra (verifique stock).")
