import tkinter as tk
from tkinter import ttk, messagebox

from app.styles import apply_styles
from app.pages.dashboard import DashboardPage
from app.pages.patients import PatientsPage
from app.pages.pet_register import PetRegisterPage
from app.pages.vet_profile import VetProfilePage
from app.pages.vets import VetsPage
from app.pages.users import UsersPage
from app.pages.login import LoginPage
from app.pages.simple import SimpleLabelPage
from app.pages.appointments import AppointmentsPage
from app.pages.records import RecordsPage
from app.pages.vet_schedule import VetSchedulePage
from app.pages.marketplace import MarketplacePage

class TopBar(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding=(12, 8))
        self.title_var = tk.StringVar(value="Inicio")
        ttk.Label(self, textvariable=self.title_var, style="H1.TLabel").pack(side="left")
        self.user_var = tk.StringVar(value="No autenticado")
        ttk.Label(self, textvariable=self.user_var).pack(side="right")

    def set_title(self, text: str):
        self.title_var.set(text)

    def set_user(self, user: str | None, role: str | None):
        if user:
            r = (role or "").strip().lower()
            if r not in ("cliente", "veterinario"):
                r = ""
            role_txt = f" ({r})" if r else ""
            self.user_var.set(f"Usuario: {user}{role_txt}")
        else:
            self.user_var.set("No autenticado")

class Sidebar(ttk.Frame):
    def __init__(self, master, on_nav):
        super().__init__(master, padding=8)
        self.on_nav = on_nav
        self._buttons = {}
        self._build()

    def _btn(self, text, key):
        b = ttk.Button(self, text=text, style="Sidebar.TButton", command=lambda: self.on_nav(key))
        b.pack(fill="x", pady=2)
        self._buttons[key] = b
        return b

    def _build(self):
        ttk.Label(self, text="Menú", style="H3.TLabel").pack(anchor="w", pady=(0, 4))
        self._btn("Inicio", "dashboard")
        self._btn("Mis mascotas / Pacientes", "patients")
        self._btn("Registrar mascota", "pet_register")
        self._btn("Agendar cita", "appointments")
        self._btn("Mi agenda (veterinario)", "vet_schedule")
        self._btn("Expedientes", "records")
        self._btn("Veterinarios", "vets")
        self._btn("Mi perfil veterinario", "vet_profile")
        self._btn("Marketplace", "marketplace")  # NUEVO
        self._btn("Registro de usuario", "users")
        self._btn("Iniciar sesión", "login")
        self._btn("Inventario", "inventory")
        self._btn("Facturación", "billing")
        self._btn("Reportes", "reports")
        self._btn("Ajustes", "settings")

    def set_access_by_role(self, role: str | None):
        role_norm = (role or "").strip().lower()
        for key in ["patients","pet_register","appointments","vet_schedule","records","vets","vet_profile","marketplace"]:
            btn = self._buttons.get(key)
            if btn:
                btn.state(["disabled"])

        if not role_norm:
            return

        if role_norm == "cliente":
            enable = ["patients","pet_register","appointments","vets","marketplace"]
            for key in enable:
                btn = self._buttons.get(key); btn and btn.state(["!disabled"])
        elif role_norm == "veterinario":
            enable = ["patients","vet_schedule","records","vets","vet_profile"]
            for key in enable:
                btn = self._buttons.get(key); btn and btn.state(["!disabled"])

class MainApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("TicoPet • Registro veterinario")
        self.geometry("1120x720")
        self.minsize(980, 640)

        apply_styles(self)

        self.main = ttk.Frame(self, padding=0)
        self.main.pack(fill="both", expand=True)

        self.topbar = TopBar(self.main)
        self.topbar.grid(row=0, column=0, columnspan=2, sticky="ew")

        self.sidebar = Sidebar(self.main, self.navigate)
        self.sidebar.grid(row=1, column=0, sticky="nsw")

        self.content = ttk.Frame(self.main)
        self.content.grid(row=1, column=1, sticky="nsew")

        self.main.rowconfigure(1, weight=1)
        self.main.columnconfigure(1, weight=1)
        self.content.rowconfigure(0, weight=1)
        self.content.columnconfigure(0, weight=1)

        self.current_user_id: int | None = None
        self.current_user_name: str | None = None
        self.current_user_role: str | None = None

        self.pages = {
            "dashboard":    DashboardPage(self.content),
            "patients":     PatientsPage(self.content),
            "pet_register": PetRegisterPage(self.content),
            "appointments": AppointmentsPage(self.content),
            "vet_schedule": VetSchedulePage(self.content),
            "records":      RecordsPage(self.content),
            "vets":         VetsPage(self.content),
            "vet_profile":  VetProfilePage(self.content),
            "marketplace":  MarketplacePage(self.content),  # NUEVO
            "users":        UsersPage(self.content),
            "login":        LoginPage(self.content),
            "inventory":    SimpleLabelPage(self.content, "Inventario"),
            "billing":      SimpleLabelPage(self.content, "Facturación"),
            "reports":      SimpleLabelPage(self.content, "Reportes"),
            "settings":     SimpleLabelPage(self.content, "Ajustes"),
        }

        self.navigate("dashboard")
        self.sidebar.set_access_by_role(None)

        self.bind_all("<Control-l>", lambda e: self.navigate("login"))
        self.bind_all("<Control-u>", lambda e: self.navigate("users"))
        self.bind_all("<Control-p>", lambda e: self.navigate("pet_register"))
        self.bind_all("<Control-a>", lambda e: self.navigate("appointments"))
        self.bind_all("<Control-m>", lambda e: self.navigate("marketplace"))

    def navigate(self, key: str):
        role_norm = (self.current_user_role or "").strip().lower()

        if key == "appointments" and role_norm != "cliente":
            messagebox.showwarning("Navegación", "Solo los clientes pueden agendar citas.")
            key = "vet_schedule" if role_norm == "veterinario" else "dashboard"
        if key == "records" and role_norm != "veterinario":
            messagebox.showwarning("Navegación", "Solo veterinarios pueden ver expedientes.")
            key = "dashboard"
        if key == "marketplace" and role_norm != "cliente":
            messagebox.showwarning("Navegación", "Solo clientes pueden acceder al Marketplace.")
            key = "dashboard"

        page = self.pages.get(key)
        if page is None:
            messagebox.showerror("Navegación", f"No existe la página '{key}'.")
            return
        for p in self.pages.values():
            try:
                p.grid_forget()
            except Exception:
                pass
        page.grid(row=0, column=0, sticky="nsew")

        if hasattr(page, "refresh"):
            try: page.refresh()
            except Exception: pass

        titulos = {
            "dashboard": "Inicio",
            "patients": "Mis mascotas / Pacientes",
            "pet_register": "Registro de mascota",
            "appointments": "Agendar cita (cliente)",
            "vet_schedule": "Mi agenda (veterinario)",
            "records": "Expedientes",
            "vets": "Veterinarios",
            "vet_profile": "Mi perfil veterinario",
            "marketplace": "Marketplace",
            "users": "Registro de usuario",
            "login": "Iniciar sesión",
            "inventory": "Inventario",
            "billing": "Facturación",
            "reports": "Reportes",
            "settings": "Ajustes",
        }
        self.topbar.set_title(titulos.get(key, ""))

    def set_authenticated(self, user_id: int, nombre: str | None, role: str | None):
        role_norm = (role or "").strip().lower()
        if role_norm not in ("cliente", "veterinario"):
            role_norm = "cliente"
        self.current_user_id = user_id
        self.current_user_name = nombre or ""
        self.current_user_role = role_norm
        self.topbar.set_user(self.current_user_name, self.current_user_role)
        self.sidebar.set_access_by_role(self.current_user_role)
        if role_norm == "veterinario":
            self.navigate("vet_schedule")
        elif role_norm == "cliente":
            self.navigate("dashboard")
        else:
            self.navigate("dashboard")
